import a from './js/a.js'
import axios from 'axios'

console.log(axios);

a()

// axios new Axios()

// axios.baseurl axios 基础路径
