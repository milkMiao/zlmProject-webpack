import $ from 'jquery'

console.log($('div'));
