import {a} from './js/a.js'

a()

// usedExports 配置之后 会去标注未使用代码 和 使用的代码
