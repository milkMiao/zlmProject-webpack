export function a() {
	console.log('这里是a文件当中的a方法')
}

// export default a
