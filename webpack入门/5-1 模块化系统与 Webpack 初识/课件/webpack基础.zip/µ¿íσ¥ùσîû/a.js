// function a() {
// 	console.log('这里是a文件')
// }

const objA = {
	a() {
		console.log('这里是a文件')
	}
}
