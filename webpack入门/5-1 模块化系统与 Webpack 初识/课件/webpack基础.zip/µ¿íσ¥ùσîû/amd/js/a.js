define(() => {
	return {
		a() {
			console.log('这里是a模块中的a方法')
		}
	}
})
