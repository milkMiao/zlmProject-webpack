let a1 = 1000;

export default a1;