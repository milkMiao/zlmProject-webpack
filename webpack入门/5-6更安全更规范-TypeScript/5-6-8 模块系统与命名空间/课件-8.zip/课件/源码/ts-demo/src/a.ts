import b from './b';

let a1 = 100;
let a2 = 200;

console.log(b);

export default {};