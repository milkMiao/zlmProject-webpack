export let obj = {
    x: 1
}