// import v from './m1';

import {obj} from './m1';
import * as m1 from './m1';

console.log(obj.x);
console.log(m1.obj.x);


