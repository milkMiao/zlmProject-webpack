module.exports.obj = {
    x: 100
}