import m1 from './m1.js';
// import * as m1 from './m1.js';

console.log(m1);
console.log(m1.obj);



