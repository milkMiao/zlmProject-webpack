import v, {x, y} from './b.js';

console.log(x, y, v);