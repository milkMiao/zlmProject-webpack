let a = 1;
let b = 2;

export var x = a;
export var y = b;
export default a + b;