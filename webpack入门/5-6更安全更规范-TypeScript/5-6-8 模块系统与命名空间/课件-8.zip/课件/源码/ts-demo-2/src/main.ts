import m1 from './m1.js';

console.log(m1);
