import b from './b';
// import c from '../c';

import c from 'c';