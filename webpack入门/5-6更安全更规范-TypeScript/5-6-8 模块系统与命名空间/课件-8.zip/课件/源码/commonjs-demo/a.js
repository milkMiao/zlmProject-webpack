let b = require('./b');
console.log(b);