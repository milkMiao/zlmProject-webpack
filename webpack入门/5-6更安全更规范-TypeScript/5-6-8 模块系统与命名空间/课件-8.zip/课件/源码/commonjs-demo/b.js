let a = 1;
let b = 2;

module.exports = {
    x: a,
    y: b
}