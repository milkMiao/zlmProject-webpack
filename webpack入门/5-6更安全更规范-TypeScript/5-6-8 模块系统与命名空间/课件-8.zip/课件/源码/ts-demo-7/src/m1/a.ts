import b from './b';
import c from './c';
import d from './d';

import e from 'e';
import f from 'f';

import g from 'g';

g.v