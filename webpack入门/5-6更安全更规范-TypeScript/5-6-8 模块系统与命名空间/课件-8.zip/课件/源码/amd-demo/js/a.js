// define(['./b'], function(b) {
//     console.log(b);
// });

define(function(require, exports, module) {
    // console.log(b);

    let b = require('./b');
    console.log(b);
});