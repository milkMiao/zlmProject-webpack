export default function b() {
	console.log('b')
}
