import b from './b.js'

b()

export default 100
