import a from './js/a.js'
// import b from './b.js'
//
// b()

console.log(a);
